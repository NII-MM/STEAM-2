document.getElementById('botao1').addEventListener('click',function(){
  alert('CRIPTOS CONQUISTADAS!');
});

function mudarTexto() {
  document.getElementById("mensagem").innerHTML = "C";
}