function validacao() {
  let nome= document.getElementById("nome").value;
  let resultado= document.getElementById("resultado");
  resultado.innerHTML= "Que belo nome!";
    }
   
    