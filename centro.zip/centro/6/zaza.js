function sendMenssage(){
 let usarText = document.getElementById("userinput").ariaValueMax;
 let chatbox = document.getElementById("chatbox");
 
  if (userText.trim()==="") return;


  chatbox.innerHTML += <p><strong>Você:</strong> $(userText)</p>;
  document.getElementById("userInput").value = "";
  
  setTimeout(() => {
      let botresponse = getBotResponse(userText);
      chatbox.innerHTML += `<p><strong>Bot:</strong> ${botResponse}`;
      chatbox.scrollTop = chatbox.scrollHeight;
  }, 500);
}

function getBotResponse(input){
Input = input.toLowercase();

const respostas = {
"Qual o rio mais legal" : "CLARAMENTE É O RIO NILO!!!",
"tu é mó putão meu" : "𓀀 𓀁 𓀂 𓀃 𓀄 𓀅 𓀆 𓀇 𓀈 𓀉 𓀊 𓀋 𓀌 𓀍 𓀎 𓀏 𓀐 𓀑 𓀒 𓀓 𓀔 𓀕 𓀖 𓀗 𓀘 𓀙 𓀚 𓀛 𓀜 𓀝 𓀞 𓀟 𓀠 𓀡 𓀢 𓀣 𓀤 𓀥 𓀦 𓀧 𓀨 𓀩 𓀪 𓀫 𓀬 𓀭 𓀮 𓀯 𓀰 𓀱 𓀲 𓀳 𓀴 𓀵 𓀶 𓀷 𓀸 𓀹 𓀺 𓀻 𓀼 𓀽 𓀾 𓀿 𓁀 𓁁 𓁂 𓁃 𓁄 𓁅 𓁆 𓁇 𓁈 𓁉 𓁊 𓁋 𓁌 𓁍 𓁎 𓁏 𓁐 𓁑 𓀄 𓀅 𓀆 𓀇 𓀈 𓀉 𓀊 (maldição de Rá)",

};

return respostas[input] || "entendi nada mermão.";

}