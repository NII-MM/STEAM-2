function criarTabelas(){
let numColunas = document.getElementById("numColunas").value;
    let cabecalho = document.getElementById("titulo").value;
       let linhaNota = document.getElementById("linhas").value;
      titulo.innerhtml = "";
      linhaNota.innerhtml = "";
for ( let i= 1; i <=numColunas; i++ ) {
    let th = document.createElement("th");
    th.textContent = "nota" + i;
    cabecalho.appendchild(th);

let td = document.createElement("td");
let input = document.createElement("input");
input.type = "number";
input.className = "nota";
td.appendChild(input);
linhas.appendChild(td);
     }
}

function calcularmedia(){
    let inputs = document.querySelectorAll(".nota")
    let soma = 0;
    let qtd = inputs.length;
    
       input.forEach(input=> {
        soma += parseFloat(input.value) || 0;
       });

let media =qtd > 0 ? (soma/qtd).toFixed(2) : 0;
document.getElementById("resultado").textContent = "Média: " + media;
    }


