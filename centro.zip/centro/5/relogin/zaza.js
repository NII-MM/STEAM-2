function myfunction(){
    alert('esta é a horas')
  }


  function relogio() {
     let agora = new Date();
     let horas = agora.getHours().tostring().padstart(2, "0");
     let minutos = agora.getMinutes().tostring().padstart(2, "0");
     let segundos = agora.getSeconds().tostring().padstart(2, "0");
     let mine = agora.getMilliseconds().tostring().padstart(2, "0");

      document.getElementById("relogio").innerHTML = ` ${horas}:${minutos}:${segundos}:${mine} `;
  }

         setInterval(relogio, 1000)
         relogio();