particlesJS("particles-js", {
    particles: {
        number: { value: 80, density: { enable: true, value_area: 800 }},
        color: { value: "#ffffff" },
        shape: { type: "circle" },
        opacity: { value: 0.5 },
        size: { value: 3 },
        line_linked: { enable: true, distance: 150, color: "#ffffff", opacity: 0.4, width: 1 },
        move: { enable: true, speed: 2 }
    },
    interactivity: {
        detect_on: "canvas",
        events: {
            onhover: { enable: true, mode: "repulse" },
            onclick: { enable: true, mode: "push" }
        },
        modes: { repulse: { distance: 100 }, push: { particles_nb: 4 } }
    },
    retina_detect: true
});

const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const towerimg = new Image();
const bgMusic = document.getElementById('bgMusic');
bgMusic.volume = 0.3;
let money = 100;
let lives = 10;
let enemies = [];
let towers = [];
let placingTower = false;
let projectiles = [];
let gameStarted = false;
let spawnInterval = 6000;
let wave = 1;

towerimg.src = 'tower.png';


class Enemy {
    constructor() {
        this.t = 0;
        this.health = 2;
        this.speed = 0.0017;
        this.flashUntil = 0;
        this.x = 0;
        this.y = 0;
    }
}

class Tower {
    constructor(x, y, type) {
        this.x = x;
        this.y = y;
        this.type = type;
        this.range = 130;
        this.attackDamage = type === "debuff" ? 0 : 1;
        this.attackSpeed = 1000;
        this.lastAttack = 0;
        this.effectTick = Date.now();
        this.rotation = 0; 
    }
}


class Projectile {
    constructor(x, y, target, damage) {
        this.x = x;
        this.y = y;
        this.target = target;
        this.speed = 8;
        this.damage = damage;
    }
}

function getInfinityPathPoint(t) {
    const a = 400;
    const b = 325;
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const angle = t * 2 * Math.PI;
    return {
        x: centerX + a * Math.sin(angle),
        y: centerY + b * Math.sin(angle) * Math.cos(angle)
    };
}

function spawnEnemy() {
    enemies.push(new Enemy());
}

function drawEnemies() {
    enemies.forEach(enemy => {
        ctx.beginPath();
        ctx.arc(enemy.x, enemy.y, 10, 0, Math.PI * 2);
        ctx.fillStyle = Date.now() < enemy.flashUntil ? "white" : "red";
        ctx.fill();
    });
}

function moveEnemies() {
    enemies.forEach(enemy => {
        enemy.t += enemy.speed;
        if (enemy.t >= 3) {
            lives--;
            enemies = enemies.filter(e => e !== enemy);
            return;
        }
        const pos = getInfinityPathPoint(enemy.t);
        enemy.x = pos.x;
        enemy.y = pos.y;
    });
}

function checkIfNearPath(x, y) {
    for (let i = 0; i <= 3; i += 0.01) {
        const point = getInfinityPathPoint(i);
        const dist = Math.hypot(point.x - x, point.y - y);
        if (dist < 30) return true;
    }
    return false;
}

function drawInfinityPath() {
    ctx.beginPath();
    for (let t = 0; t <= 3; t += 0.01) {
        const p = getInfinityPathPoint(t);
        if (t === 0) ctx.moveTo(p.x, p.y);
        else ctx.lineTo(p.x, p.y);
    }
    ctx.strokeStyle = "#888";
    ctx.lineWidth = 3;
    ctx.stroke();
}

function lerpAngle(a, b, t) {
    const diff = ((b - a + Math.PI * 3) % (Math.PI * 2)) - Math.PI;
    return a + diff * t;
}


function drawTowers() {
    towers.forEach(tower => {
        let nearest = null;
        let minDist = Infinity;

        enemies.forEach(enemy => {
            const dist = Math.hypot(enemy.x - tower.x, enemy.y - tower.y);
            if (dist < tower.range && dist < minDist) {
                nearest = enemy;
                minDist = dist;
            }
        });

        if (nearest && tower.type !== "debuff") {
            const dx = nearest.x - tower.x;
            const dy = nearest.y - tower.y;
            const targetAngle = Math.atan2(dy, dx);
            tower.rotation = lerpAngle(tower.rotation, targetAngle, 0.1);
        }

        ctx.save();
        ctx.translate(tower.x, tower.y);
        ctx.rotate(tower.rotation);
        ctx.drawImage(towerimg, -50, -50, 120, 120);
        ctx.restore();
    });
}



function attackEnemies() {
    const currentTime = Date.now();
    
    towers.forEach(tower => {
        if (tower.type === "debuff") {
            if (currentTime - tower.effectTick > 1000) {
                enemies.forEach(enemy => {
                    const dist = Math.hypot(tower.x - enemy.x, tower.y - enemy.y);
                    if (dist < tower.range) {
                        enemy.health -= 0.55;
                        if (enemy.health <= 0) {
                            enemies = enemies.filter(e => e !== enemy);
                            money += 10;
                        }
                    }
                });
                tower.effectTick = currentTime;
            }
            return;
        }

        const target = enemies.find(enemy => 
            Math.hypot(tower.x - enemy.x, tower.y - enemy.y) < tower.range
        );

        if (target && currentTime - tower.lastAttack > tower.attackSpeed) {
            if (tower.type === "triple") {
                for (let i = -1; i <= 1; i++) {
                    const offsetTarget = { 
                        x: target.x + i * 10, 
                        y: target.y + i * 10,
                        health: target.health,
                        flashUntil: target.flashUntil
                    };
                    projectiles.push(new Projectile(tower.x, tower.y, offsetTarget, tower.attackDamage));
                }
            } else {
                projectiles.push(new Projectile(tower.x, tower.y, target, tower.attackDamage));
            }
            tower.lastAttack = currentTime;
        }
    });
}

function moveProjectiles() {
    projectiles = projectiles.filter(p => {
        const dx = p.target.x - p.x;
        const dy = p.target.y - p.y;
        const dist = Math.hypot(dx, dy);

        if (dist < 5) {
            p.target.health -= p.damage;
            p.target.flashUntil = Date.now() + 100;
            if (p.target.health <= 0) {
                enemies = enemies.filter(e => e !== p.target);
                money += 10;
            }
            return false;
        }

        p.x += (dx / dist) * p.speed;
        p.y += (dy / dist) * p.speed;
        return true;
    });
}

function drawProjectiles() {
    projectiles.forEach(p => {
        ctx.beginPath();
        ctx.arc(p.x, p.y, 4, 0, Math.PI * 2);
        ctx.fillStyle = "yellow";
        ctx.fill();
    });
}

function updateUI() {
    document.getElementById('score').textContent = `Voidium: ${money}`;
    document.getElementById('lives').textContent = `Vidas: ${lives}`;
}

function checkGameOver() {
    if (lives <= 0) {
        alert(`Game Over! Wave: ${wave}`);
        resetGame();
    }
}

function resetGame() {
    money = 100;
    lives = 10;
    enemies = [];
    towers = [];
    projectiles = [];
    wave = 24;
    spawnInterval = 6000;
}

function spawnWave() {
    for (let i = 0; i < wave * 2000; i++) {
        setTimeout(spawnEnemy, i * 1000);
    }
    wave++;
    spawnInterval = Math.max(2000, spawnInterval - 200);
}

function gameLoop() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    drawInfinityPath();
    drawEnemies();
    drawTowers();
    moveEnemies();
    attackEnemies();
    moveProjectiles();
    drawProjectiles();
    updateUI();
    checkGameOver();
    
    requestAnimationFrame(gameLoop);
}

function startGame() {
    spawnWave();
    gameLoop();
    bgMusic.play();
}

canvas.addEventListener('click', (e) => {
    if (!placingTower) return;
    
    const rect = canvas.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;
    
    if (checkIfNearPath(mouseX, mouseY)) {
        alert("Não pode colocar torres no caminho!");
        return;
    }

    const cost = 
        placingTower === "triple" ? 100 : 
        placingTower === "debuff" ? 80 : 50;

    if (money >= cost) {
        towers.push(new Tower(mouseX, mouseY, placingTower));
        money -= cost;
        placingTower = false;
    } else {
        alert("Voidium insuficiente!");
    }
});

document.getElementById('basicTowerBtn').addEventListener('click', () => {
    placingTower = "basic";
});

document.getElementById('tripleTowerBtn').addEventListener('click', () => {
    placingTower = "triple";
});

document.getElementById('debuffTowerBtn').addEventListener('click', () => {
    placingTower = "debuff";
});

document.getElementById('startBtn').addEventListener('click', () => {
    if (!gameStarted) {
        gameStarted = true;
        startGame();
        document.getElementById('intro').classList.add('fade-out');
        setTimeout(() => {
            document.querySelectorAll('.game-ui').forEach(el => el.classList.add('visible'));
        }, 1000);
    }
});
