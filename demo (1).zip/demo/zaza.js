const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
let money = 100;
let lives = 10;
let enemies = [];
let enemies2 = [];
let towers = [];
let placingTower = false;
let projectile = [];


function getInfinityPathPoint(t) {
    const a = 400;
    const b = 325; 
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const angle = t * 2 * Math.PI;

    const x = centerX + a * Math.sin(angle);
    const y = centerY + b * Math.sin(angle) * Math.cos(angle);

    return { x, y };
}

function Enemy(){
   this.t = 0;
   this.health = 2;
   this.speed = 1 / 2000;
   this.flashUntil = 0;
}


function Tower(x, y) {
    this.x = x;
    this.y = y;
    this.range = 100;
    this.attackDamage = 1;
    this.attackSpeed = 1000;
    this.lastAttack = 0;
}

function spawnEnemy() {
    let newEnemy = new Enemy(); 
    enemies.push(newEnemy);
}


function drawEnemies() {
    enemies.forEach(enemy => {
        ctx.beginPath();
        ctx.arc(enemy.x, enemy.y, 10, 0, Math.PI * 2);

        if (Date.now() < enemy.flashUntil) {
            ctx.fillStyle = "white";
        } else {
            ctx.fillStyle = "red"; 
        }

        ctx.fill();
        ctx.closePath();
    });
}

function moveEnemies() {
    enemies.forEach(enemy => {
        enemy.t += enemy.speed;
        if (enemy.t >= 3) {
            lives--;
            enemies = enemies.filter(e => e !== enemy);
            return;
        }

        const pos = getInfinityPathPoint(enemy.t);
        enemy.x = pos.x;
        enemy.y = pos.y;
    });
}

canvas.addEventListener('click', function (e) {
    if (!placingTower) return;

    const rect = canvas.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    const isNearPath = checkIfNearPath(mouseX, mouseY);

    if (!isNearPath && money >= 50) {
        towers.push(new Tower(mouseX, mouseY));
        money -= 50;
        placingTower = false;
    } else {
        alert("Não é possível colocar a torre nesse local!");
    }
});


function checkIfNearPath(x, y) {
    for (let i = 0; i <= 1; i += 0.01) {
        const point = getInfinityPathPoint(i);
        const dx = point.x - x;
        const dy = point.y - y;
        const dist = Math.sqrt(dx * dx + dy * dy); 

        if (dist < 30) return true; 
    }
    return false;
}

function drawInfinityPath() {
    ctx.beginPath();
    for (let t = 0; t <= 1; t += 0.01) {
        const p = getInfinityPathPoint(t);
        if (t === 0) ctx.moveTo(p.x, p.y);
        else ctx.lineTo(p.x, p.y);
    }
    ctx.strokeStyle = "#888";
    ctx.lineWidth = 3;
    ctx.stroke();
}


function drawTowers() {
    towers.forEach(tower => {
        ctx.beginPath();
        ctx.arc(tower.x, tower.y, 20, 0, Math.PI * 2);
        ctx.fillStyle = "blue";
        ctx.fill();
        ctx.closePath();
    });
}

function attackEnemies() {
    towers.forEach(tower => {
        let currentTime = Date.now();
        let target = enemies.find(enemy => {
            let dist = Math.hypot(tower.x - enemy.x, tower.y - enemy.y);
            return dist < tower.range;
        });

        if (target && currentTime - tower.lastAttack > tower.attackSpeed) {
            let p = new Projectile(tower.x, tower.y, target, tower.attackDamage);
            projectile.push(p);
            tower.lastAttack = currentTime;
        }
    });
}


function Projectile(x, y, target, damage) {
    this.x = x;
    this.y = y;
    this.target = target;
    this.speed = 5;
    this.damage = damage;
}

function moveProjectile() {
    projectile = projectile.filter(p => {
        let dx = p.target.x - p.x;
        let dy = p.target.y - p.y;
        let dist = Math.sqrt(dx * dx + dy * dy);

        if (dist < 5) {
            p.target.health -= p.damage;
            p.target.flashUntil = Date.now() + 100;

            if (p.target.health <= 0) {
                enemies = enemies.filter(e => e !== p.target);
                money += 10;
            }
            return false;
        }

        p.x += (dx / dist) * p.speed;
        p.y += (dy / dist) * p.speed;
        return true;
    });
}

function drawProjectile() {
    projectile.forEach(p => {
        ctx.beginPath();
        ctx.arc(p.x, p.y, 4, 0, Math.PI * 2);
        ctx.fillStyle = "yellow";
        ctx.fill();
        ctx.closePath();
    });
}


function update() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    drawInfinityPath();
    drawEnemies();
    drawTowers();
    moveEnemies();
    attackEnemies();
    moveProjectile();
    drawProjectile();

    
    document.getElementById('score').innerText = "Voidium: " + money;
    document.getElementById('lives').innerText = "Vidas: " + lives;
    
    if (lives <= 0) {
        alert("Game Over!");
        resetGame();
    }
}


function resetGame() {
    money = 100;
    lives = 10;
    enemies = [];
    towers = [];
}

function gameLoop() {
    update();
    requestAnimationFrame(gameLoop);
}

setInterval(spawnEnemy, 5000); 

gameLoop();

document.getElementById('basicTowerBtn').addEventListener('click', () => {
    if (money >= 50) {
        placingTower = true;
    } else {
        alert("Voidiuns insuficiente!");
    }
});

